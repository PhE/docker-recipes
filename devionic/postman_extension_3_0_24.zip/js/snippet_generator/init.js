$(document).ready(function() {
    window.addEventListener('message', function(event) {
        var command = event.data.command;
        

        

    });
});

