// Constants
var POSTMAN_WEB_URL_PRODUCTION = "https://www.getpostman.com";
var POSTMAN_WEB_URL_STAGING = "https://stage.getpostman.com";
var POSTMAN_WEB_URL_DEV = "http://dev.getpostman.com";
var POSTMAN_WEB_URL_LOCAL = "http://dev.getpostman.com";
var POSTMAN_WEB_URL_SYNC_STAGE = "https://beta.getpostman.com";
var POSTMAN_WEB_URL_SYNC_DEV = "https://sync-dev.getpostman.com";
//var POSTMAN_WEB_URL_SYNC_DEV = "https://sync-staging.getpostman.com";

var POSTMAN_INTERCEPTOR_ID_PRODUCTION = "aicmkgpgakddgnaphhhpliifpcfhicfo";
var POSTMAN_INTERCEPTOR_ID_STAGING = "flaanggmaikfebcchaambfkdefklniag";
var POSTMAN_INTERCEPTOR_ID_DEV = "cjjnlahgfafgalfgmabkndcldfdinjci";
var POSTMAN_INTERCEPTOR_ID_LOCAL = "lcjlpdnimfimebpailijjlpjbldigdjj";
var POSTMAN_INTERCEPTOR_ID_SYNC_STAGE = "hfhmekcnabkelajbpjkinmhaplilkicm";
var POSTMAN_INTERCEPTOR_ID_SYNC_DEV = "lcjlpdnimfimebpailijjlpjbldigdjj";

var POSTMAN_INDEXED_DB_PRODUCTION = "postman";
var POSTMAN_INDEXED_DB_TESTING = "postman_test";

var POSTMAN_SYNCSERVER_LOCAL = "http://localhost:1337";
var POSTMAN_SYNCSERVER_STAGING = "http://sync-server.getpostman.com";
var POSTMAN_SYNCSERVER_DEV = "http://sync.getpostman.com";//"http://104.200.18.102:1337";
var POSTMAN_SYNCSERVER_PRODUCTION = "https://sync.getpostman.com";
var POSTMAN_SYNCSERVER_SYNC_STAGE = "https://sync-stage.getpostman.com";
var POSTMAN_SYNCSERVER_SYNC_DEV = "http://postman-sync-dev-b.elasticbeanstalk.com";

var POSTMAN_OAUTH2_CALLBACK_URL_PRODUCTION = "https://www.getpostman.com/oauth2/callback";
var POSTMAN_OAUTH2_CALLBACK_URL_SYNC_STAGE = "http://sync-staging.getpostman.com/oauth2/callback";
var POSTMAN_OAUTH2_CALLBACK_URL_STAGING = "http://stage.getpostman.com:443";
var POSTMAN_OAUTH2_CALLBACK_URL_DEV = "http://dev.getpostman.com";
var POSTMAN_OAUTH2_CALLBACK_URL_SYNC_DEV = "http://sync-staging.getpostman.com/oauth2/callback";
var POSTMAN_OAUTH2_CALLBACK_URL_SYNC_STAGE = "http://sync-staging.getpostman.com/oauth2/callback";

var GA_TRACKING_PROD = 'UA-43979731-6';
var GA_TRACKING_SYNC_STAGE = 'UA-43979731-8';

var SENTRY_DSN = 'https://dcc9c5bd36884b938f995aaa9eedce03@app.getsentry.com/53934';
var ENABLE_CRASH_REPORTING = false;

// Config variables
var postman_flag_is_testing = {{ is_testing }};
var postman_web_url = {{ web_url }};
var postman_all_purchases_available = {{ purchases }};
var postman_interceptor_id = {{ interceptor_id }};
var postman_syncserver_url = {{ syncserver_url }};
var postman_oauth2_callback_url = {{ oauth2_callback_url }};
var postman_ga_tracking_id = {{ ga_tracking_id }};

var postman_sync_api_version = "v1";

var postman_env = {{ postman_env }};

var postman_webkit = {{ webkit }};
var postman_macgap = {{ macgap }};
var postman_brackets = {{ brackets }};
var postman_electron = {{ electron }};

var postman_trial_duration = 1209600000; // 14 days
// var postman_trial_duration = 1000 * 60 * 60 * 2;

var postman_database_name;

var postman_sync_rawtext_limit = 100000;

if (postman_flag_is_testing) {
	postman_database_name = POSTMAN_INDEXED_DB_TESTING;
}
else {
	postman_database_name = POSTMAN_INDEXED_DB_PRODUCTION;
}
