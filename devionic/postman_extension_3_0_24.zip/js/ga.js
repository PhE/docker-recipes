var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-26564585-3']);
_gaq.push(['_trackPageview']);

(function () {
    var ga = document.createElement('script');
    ga.type = 'text/javascript';
    ga.async = true;
    ga.src = 'https://ssl.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(ga, s);
})();
/**
 * Created with JetBrains PhpStorm.
 * User: asthana
 * Date: 06/08/12
 * Time: 11:25 AM
 * To change this template use File | Settings | File Templates.
 */
